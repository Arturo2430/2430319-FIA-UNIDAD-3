"""Repair must preserve routes, keys, budgets and independently certified success."""

from dataclasses import asdict
import json
from pathlib import Path

import numpy as np
import pytest

from src.algorithms import abc, differential
from src.algorithms.cycle_repair import encode_route, repair_candidate
from src.algorithms.execution import Budget, SolverRun, start_run
from src.algorithms.real_keys import decode_real_keys
from src.cli.variants import VARIANTS, effective_variant
from src.evaluation import evaluate_cost, validate_cycle
from src.graphs import Graph


def cycle(chord=False):
    edges = [(i, (i + 1) % 6) for i in range(6)]
    return Graph(range(6), edges + ([(3, 5)] if chord else []))


def repaired(graph, route, seed=7, evaluations=100):
    run = start_run(graph, seed=seed, budget=Budget(max_evaluations=evaluations),
                    iteration_unit='test', clock=lambda: 0)
    assert isinstance(run, SolverRun)
    assert run.begin_phase('candidate', 1)
    cost = run.evaluate(route, evaluate_cost)
    value = repair_candidate(graph, route, cost, run, {'repair_steps': 64, 'repair_threshold': 3})
    return run, value


def test_three_segment_exchange_closes_full_path_and_preserves_input():
    graph = cycle(chord=True)
    original = (0, 1, 2, 3, 5, 4)
    assert evaluate_cost(graph, original) == 1
    run, (route, cost) = repaired(graph, original)
    assert original == (0, 1, 2, 3, 5, 4)
    assert cost == 0 and validate_cycle(graph, route).valid
    result = run.certify_best()
    assert result.success_within_budget
    assert result.counters.algorithm_counters['repair_three_segment_closures'] == 1


def test_gap_repair_can_use_last_admitted_evaluation():
    graph = cycle()
    original = (0, 2, 1, 3, 4, 5)
    assert evaluate_cost(graph, original) == 2
    run, (route, cost) = repaired(graph, original, evaluations=2)
    assert cost == 0 and validate_cycle(graph, route).valid
    result = run.certify_best()
    assert result.success_within_budget and result.counters.evaluations_started == 2


def test_repair_cannot_exceed_shared_evaluation_limit():
    run, value = repaired(cycle(True), (0, 1, 2, 3, 5, 4), evaluations=1)
    assert value == (None, None)
    result = run.finish()
    assert result.stop_reason == 'evaluation_limit'
    assert result.counters.evaluations_started == 1


def test_deadline_interrupts_repair_without_false_success():
    class Clock:
        now = 0

        def __call__(self):
            self.now += 1
            return self.now

    clock = Clock()
    graph = cycle(True)
    run = start_run(graph, seed=7, budget=Budget(max_elapsed_ns=100),
                    iteration_unit='test', clock=clock)
    assert run.begin_phase('candidate', 1)
    route = (0, 1, 2, 3, 5, 4)
    cost = run.evaluate(route, evaluate_cost)
    clock.now = 99
    assert repair_candidate(graph, route, cost, run, {'repair_steps': 64}) == (None, None)
    result = run.finish()
    assert result.stop_reason == 'time_limit' and not result.success_within_budget


def test_path_without_closing_edge_is_not_reported_as_cycle():
    graph = Graph(range(6), [(i, i + 1) for i in range(5)])
    run, (route, cost) = repaired(graph, tuple(range(6)))
    assert cost == evaluate_cost(graph, route) == 1
    assert not validate_cycle(graph, route).valid
    assert not run.finish().success_within_budget


def test_seed_reproduces_repair_and_counters():
    run1, value1 = repaired(cycle(True), (0, 1, 2, 3, 5, 4))
    run2, value2 = repaired(cycle(True), (0, 1, 2, 3, 5, 4))
    assert value1 == value2
    assert asdict(run1.certify_best()) == asdict(run2.certify_best())


@pytest.mark.parametrize('keys', [np.array([7., 1., 3., 5., 2., 4.]), np.ones(6)])
def test_repaired_keys_decode_exactly_and_do_not_alias(keys):
    route = (5, 3, 1, 4, 0, 2)
    before = keys.copy()
    encoded = encode_route(route, keys)
    assert decode_real_keys(6, encoded) == route
    assert np.array_equal(keys, before)
    assert np.isfinite(encoded).all() and not np.shares_memory(keys, encoded)


def test_abc_neutral_moves_are_bounded_and_do_not_reset_trials():
    source = abc._Source((0, 1, 2, 3), 2, 99)
    abc._accept(source, (1, 0, 2, 3), 2, neutral_limit=1)
    assert source.trials == 100 and source.neutral_steps == 1
    abc._accept(source, (2, 0, 1, 3), 2, neutral_limit=1)
    assert source.route == (1, 0, 2, 3) and source.trials == 101
    abc._accept(source, (0, 2, 1, 3), 1, neutral_limit=1)
    assert source.trials == source.neutral_steps == 0


def test_de_neutral_replacements_are_bounded_per_target():
    graph = Graph(range(5), [])
    result = differential.solve_de(graph, parameters={
        'population_size': 4, 'differential_weight': .8, 'crossover_rate': .8,
        'neutral_limit': 2}, seed=7, budget=Budget(max_evaluations=80), clock=lambda: 0)
    assert result.status == 'exhausted'
    assert 0 < result.counters.algorithm_counters['neutral_replacements'] <= 8
    assert evaluate_cost(graph, result.best_route) == result.best_cost


PRESETS = json.loads((Path(__file__).resolve().parents[1] /
                     'experiments/configs/search-repair-v4-presets.json').read_text())['solvers']


@pytest.mark.parametrize('solver', PRESETS, ids=lambda s: s['algorithm'])
def test_every_family_integrates_repair_with_valid_costs(solver):
    spec = VARIANTS[solver['algorithm']]
    params = spec.resolve(solver['parameters'])
    assert effective_variant(spec, params).name.endswith('_repair_v4')
    graph = cycle(True)
    result = spec.solve(graph, parameters=params, seed=7,
                        budget=Budget(max_evaluations=200), clock=lambda: 0)
    assert result.status != 'error'
    assert evaluate_cost(graph, result.best_route) == result.best_cost
    if result.success_within_budget:
        assert validate_cycle(graph, result.best_route).valid


@pytest.mark.parametrize('solver', PRESETS, ids=lambda s: s['algorithm'])
def test_every_family_actually_repairs_a_forced_candidate(solver, monkeypatch):
    from src.algorithms import genetic, annealing, ant_system, particle_swarm

    modules = {'ga': genetic, 'abc': abc, 'de': differential,
               'sa': annealing, 'as': ant_system, 'pso': particle_swarm}
    module = modules[solver['algorithm']]
    graph = cycle(True)
    route = (0, 1, 2, 3, 5, 4)
    keys = encode_route(route, np.arange(6, dtype=float))
    if solver['algorithm'] == 'as':
        monkeypatch.setattr(module, '_construct', lambda *args: route)
    elif solver['algorithm'] in ('de', 'pso'):
        monkeypatch.setattr(module, 'greedy_keys', lambda *args: keys.copy())
    else:
        monkeypatch.setattr(module, 'greedy_route', lambda *args: route)
    result = VARIANTS[solver['algorithm']].solve(
        graph, parameters=solver['parameters'], seed=7,
        budget=Budget(max_evaluations=100), clock=lambda: 0)
    assert result.success_within_budget and result.best_cost == 0
    assert validate_cycle(graph, result.best_route).valid
    assert result.counters.algorithm_counters['repair_calls'] > 0


@pytest.mark.parametrize('name,value', [('repair_steps', -1), ('repair_steps', True),
                                      ('repair_threshold', 0), ('repair_threshold', 1.2)])
def test_bad_repair_options_rejected_for_all_families(name, value):
    for solver in PRESETS:
        with pytest.raises(ValueError):
            VARIANTS[solver['algorithm']].resolve({**solver['parameters'], name: value})


def test_posa_rotations_independently_close_a_path():
    from src.algorithms.cycle_repair import _rotate_path

    graph = cycle(True)
    run = start_run(graph, seed=7, budget=Budget(max_evaluations=100),
                    iteration_unit='repair', clock=lambda: 0)
    run.begin_phase('repair', 1)
    path = (0, 1, 2, 3, 5, 4)
    run.evaluate(path, evaluate_cost)
    route, cost = _rotate_path(graph, path, run, 64)
    assert cost == 0 and validate_cycle(graph, route).valid
    result = run.certify_best()
    assert result.counters.algorithm_counters['repair_rotations_evaluated'] >= 1


@pytest.mark.parametrize('solver', PRESETS, ids=lambda s: s['algorithm'])
def test_disabled_options_reproduce_legacy_search_exactly(solver):
    spec = VARIANTS[solver['algorithm']]
    parameters = {k: v for k, v in solver['parameters'].items()
                  if k not in {'repair_steps', 'repair_threshold', 'neutral_limit'}}
    disabled = {**parameters, 'repair_steps': 0}
    if solver['algorithm'] in ('abc', 'de'):
        disabled['neutral_limit'] = 0
    graph = Graph(range(6), [(i, i + 1) for i in range(5)])
    budget = Budget(max_evaluations=150)
    original = spec.solve(graph, parameters=parameters, seed=7, budget=budget, clock=lambda: 0)
    candidate = spec.solve(graph, parameters=disabled, seed=7, budget=budget, clock=lambda: 0)
    assert asdict(original) == asdict(candidate)
