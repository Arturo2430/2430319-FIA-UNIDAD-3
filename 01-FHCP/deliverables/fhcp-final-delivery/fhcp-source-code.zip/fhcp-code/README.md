# Código ejecutable · FHCP Challenge

Este paquete carga las instancias HCP, ejecuta seis metaheurísticas y devuelve
un arreglo de vértices con la ruta propuesta. Incluye los 1001 grafos originales
y las variantes con reparación v4 utilizadas en la evaluación del informe.

Algoritmos: GA (genético), SA (recocido simulado), AS (Ant System, familia ACO),
ABC (abejas), DE (evolución diferencial) y PSO (enjambre de partículas).

## Preparar el entorno

Descomprimir el ZIP y abrir una terminal dentro de `fhcp-code`.
Entorno utilizado: Python 3.14.10 de 64 bits y NumPy 2.5.4.

Linux:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python run.py --instance graph2 --algorithm abc --seed 42 --seconds 30
```

Windows (PowerShell, con Python instalado):

```powershell
py -3.14 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe run.py --instance graph2 --algorithm abc --seed 42 --seconds 30
```

El ejecutador usa rutas portables y procesos estándar. Las comprobaciones de
esta entrega se ejecutaron en Linux; no se incluye el coordinador de campañas
con afinidad exclusiva de Linux. Instalar dependencias requiere acceso a PyPI;
las ejecuciones no descargan grafos ni necesitan Git.

## Elegir algoritmo, grafo y presupuesto

`--instance` acepta `graph1` hasta `graph1001`.
`--algorithm` acepta `ga`, `sa`, `as`, `abc`, `de`, `pso` o `all`.

Ejecutar los seis sobre un grafo, secuencialmente, con hasta 30 segundos cada uno:

```bash
python run.py --instance graph2 --algorithm all --seed 42 --seconds 30
```

Usar el Python del entorno creado arriba en lugar de `python` si no está activado.
El tiempo es por algoritmo, incluyendo su inicialización. Los seis pueden ocupar
aproximadamente tres minutos más arranque/carga; terminan antes si encuentran
un ciclo. Agotar el tiempo no demuestra que el grafo sea no hamiltoniano.
La semilla controla la aleatoriedad; no garantiza éxito.

`run.py` aplica los parámetros de
`experiments/configs/search-repair-v4-presets.json`: inicialización/guía de la
evaluación, reparación de hasta 64 pasos con umbral tres, y empates acotados a
20 en ABC/DE. El código de los algoritmos conserva exactamente sus hashes de
la evaluación v4; `run.py` solo facilita la invocación y exportación.

## Dónde está el arreglo de vértices

Cada corrida crea un UUID nuevo en `results/`:

```text
results/<uuid>/route.json      Arreglo de etiquetas originales de vértices
results/<uuid>/summary.json    Estado, costo, certificado y ruta
results/<uuid>/run.json        Registro completo: parámetros, semilla y tiempos
```

También aparece un resumen JSON en la terminal. `route.json` contiene un arreglo
de longitud n, sin repetir el primer vértice al final: el cierre es implícito.
Las etiquetas corresponden al archivo HCP original, normalmente 1 hasta n.
`run.json` conserva además la representación interna indexada desde cero.

**`certified_cycle=true` indica ciclo hamiltoniano válido encontrado dentro del
presupuesto.** Si es falso, la ruta es solo el mejor candidato disponible y puede
contener transiciones ausentes. Si no se construyó candidato, el arreglo es `null`.
La validación comprueba permutación, aristas consecutivas y cierre, separada del
fitness. No se entregan tours oficiales como si fueran soluciones del algoritmo.

Para guardar en otra carpeta, añadir `--output-dir otra-carpeta`.
Las ejecuciones anteriores se conservan en sus respectivos UUID.

## CLI completa y código

Para consultar opciones de cada implementación:

```bash
python -m src.cli --help
```

La CLI directa permite modificar parámetros; por sí sola no activa los presets
v4 de `run.py`. Dominio: `src/graphs`, `src/algorithms`, `src/evaluation`.
Interfaz: `src/cli` y `run.py`. El código no depende del PDF ni de LaTeX.

## Pruebas de software

Se incluye una selección de pruebas de grafos, validación, fitness, operadores,
presupuestos, reproducibilidad y las seis familias, con reparación v4.

```bash
python -m pip install -r requirements-test.txt
python -m pytest -q tests
```

No se necesita Matplotlib ni TeX para ejecutar algoritmos o estas pruebas.
`verification.json` registra las comprobaciones de este paquete.
`file-manifest.json` contiene hashes de todos los archivos entregados salvo el
propio manifiesto.

## Procedencia y versión

Repositorio: https://github.com/ZapataFrame/FHCP-Challenge

Dataset: FHCP Challenge Set, Flinders Hamiltonian Cycle Project.
Las cabeceras de los HCP conservan la procedencia original. El catálogo incluido
registra URL de origen de los archivos oficiales, metadatos y SHA-256 de cada
instancia; el cargador comprueba sus bytes antes de ejecutar.

Se incluye exclusivamente la entrada de grafos, sin tours oficiales. El archivo
`package-info.json` identifica revisión base y hashes de fuentes de la versión
optimizada, incluidos los cambios locales que aún no forman un commit nuevo.
Este ZIP contiene fuentes ejecutables, no un binario con Python integrado.
