"""Opt-in, budgeted repair of nearly Hamiltonian permutations.

No graph files or reference tours are read. Every proposed candidate goes
through SolverRun, so repair shares the original clock and evaluation budget.
"""

from collections import deque
from collections.abc import Mapping
from itertools import combinations

import numpy as np

from src.evaluation import evaluate_cost
from src.graphs import Graph
from .execution import SolverRun
from .local_moves import RouteMove

REPAIR_OPTIONS = frozenset({'repair_steps', 'repair_threshold'})


def resolve_repair_options(values: Mapping, error_type) -> dict:
    if not (REPAIR_OPTIONS & values.keys()):
        return {}
    steps = values.get('repair_steps', 0)
    threshold = values.get('repair_threshold', 3)
    for name, value, minimum in [('repair_steps', steps, 0), ('repair_threshold', threshold, 1)]:
        if type(value) is not int or value < minimum:
            raise error_type('invalid_parameter', name, f'Expected an integer >= {minimum}.')
    return {'repair_steps': steps, 'repair_threshold': threshold}


def resolve_neutral_option(values: Mapping, error_type) -> dict:
    if 'neutral_limit' not in values:
        return {}
    value = values['neutral_limit']
    if type(value) is not int or value < 0:
        raise error_type('invalid_parameter', 'neutral_limit', 'Expected an integer >= 0.')
    return {'neutral_limit': value}


def encode_route(route, previous_keys):
    """Assign sorted existing keys in repaired order, retaining their scale.

    Tied keys need distinct ranks to guarantee the repaired decoding. Keys
    already known to be finite come from the solver's validated key state.
    """
    ordered = np.sort(previous_keys)
    if np.any(ordered[1:] == ordered[:-1]):
        ordered = np.arange(len(route), dtype=np.float64) / len(route)
    keys = np.empty(len(route), dtype=np.float64)
    keys[np.asarray(route)] = ordered
    return keys


def _gaps(graph, route, run):
    gaps = []
    for i, vertex in enumerate(route):
        if not run.checkpoint():
            return None
        if not graph.has_edge(vertex, route[(i + 1) % len(route)]):
            gaps.append(i)
    return gaps


def _close_path(graph, route, gap, run, steps):
    """Bounded Pósa rotations on a full path exposed by its sole missing edge."""
    path = route[gap + 1:] + route[:gap + 1]
    # A three-segment exchange may cross a plateau that path rotations alone
    # cannot cross. Candidate cuts come from neighbors of the two free ends.
    positions = {v: i for i, v in enumerate(path)}
    cuts = set()
    for endpoint in (path[0], path[-1]):
        for neighbor in graph.neighbors(endpoint):
            if not run.checkpoint():
                return None, None
            position = positions[int(neighbor)]
            cuts.update(i for i in (position - 1, position) if 0 <= i < len(path) - 1)
    pairs = list(combinations(sorted(cuts), 2))
    used = 0
    for pair_index in run.rng.permutation(len(pairs)):
        first, second = pairs[int(pair_index)]
        # Store segment bounds; only materialize a route after all joins exist.
        a, b, c = (0, first), (first + 1, second), (second + 1, len(path) - 1)
        for middle, last in ((b, c), (c, b)):
            for flip_middle, flip_last in ((False, False), (False, True), (True, False), (True, True)):
                if used >= steps:
                    break
                if not run.checkpoint():
                    return None, None
                used += 1
                run.count('repair_three_segment_attempts')
                m0, m1 = middle[::-1] if flip_middle else middle
                l0, l1 = last[::-1] if flip_last else last
                if not (graph.has_edge(path[a[1]], path[m0])
                        and graph.has_edge(path[m1], path[l0])
                        and graph.has_edge(path[l1], path[a[0]])):
                    continue
                segment_middle = path[middle[0]:middle[1] + 1]
                segment_last = path[last[0]:last[1] + 1]
                child = (path[:first + 1]
                         + (segment_middle[::-1] if flip_middle else segment_middle)
                         + (segment_last[::-1] if flip_last else segment_last))
                value = run.evaluate(child, evaluate_cost)
                if value is None:
                    return None, None
                if value != 0:
                    raise ValueError('A three-segment closure failed full cost verification.')
                run.count('repair_three_segment_closures')
                return child, value
            if used >= steps:
                break
        if used >= steps:
            break
    return _rotate_path(graph, path, run, steps)


def _rotate_path(graph, path, run, steps):
    """Bounded rotations, including reversed paths to expose either endpoint."""
    original = path
    queue = deque([path, path[::-1]])
    seen = {path, path[::-1]}
    used = 0
    while queue and used < steps:
        if not run.checkpoint():
            return None, None
        path = queue.popleft()
        positions = {v: i for i, v in enumerate(path)}
        neighbors = graph.neighbors(path[-1])
        for offset in run.rng.permutation(len(neighbors)):
            if used >= steps:
                break
            if not run.checkpoint():
                return None, None
            used += 1
            run.count('repair_rotation_attempts')
            position = positions[int(neighbors[int(offset)])]
            if position == 0:
                # Re-evaluation and independent certification remain mandatory.
                cost = run.evaluate(path, evaluate_cost)
                return (path, cost) if cost is not None else (None, None)
            if position >= len(path) - 2:
                continue
            child = path[:position + 1] + path[:position:-1]
            if child in seen:
                continue
            seen.add(child)
            cost = run.evaluate(child, evaluate_cost)
            if cost is None:
                return None, None
            run.count('repair_rotations_evaluated')
            if cost == 0:
                return child, cost
            # A rotation preserves all path edges; only its closing edge can fail.
            if cost != 1:
                raise ValueError('A path rotation broke the path invariant.')
            queue.append(child)
            reverse = child[::-1]
            if reverse not in seen:
                seen.add(reverse)
                queue.append(reverse)
    return original, 1


def repair_candidate(graph: Graph, route, cost: int, run: SolverRun, parameters):
    """Keep the best candidate; stop immediately when the shared budget stops.

    Higher-cost routes use inversions anchored at a missing edge, accepting
    nonworsening internal steps with a bounded visited set. Cost-one routes
    expose a Hamiltonian path and try rotations of either endpoint.
    """
    steps = parameters.get('repair_steps', 0)
    if not steps or cost == 0 or cost > parameters.get('repair_threshold', 3):
        return route, cost
    run.count('repair_calls')
    route = tuple(route)
    current, current_cost = route, cost
    best, best_cost = route, cost
    seen = {route}
    for index in range(steps):
        gaps = _gaps(graph, current, run)
        if gaps is None:
            return None, None
        if current_cost == 1:
            candidate, value = _close_path(graph, current, gaps[0], run, steps - index)
            if candidate is None:
                return None, None
            if value < best_cost:
                run.count('repair_improvements')
                return candidate, value
            break
        gap = gaps[int(run.rng.integers(len(gaps)))]
        rotated = current[gap:] + current[:gap]
        positions = {v: i for i, v in enumerate(rotated)}
        candidates = []
        for vertex in graph.neighbors(rotated[0]):
            if not run.checkpoint():
                return None, None
            position = positions[int(vertex)]
            if 2 <= position < len(rotated) - 1:
                candidates.append(position)
        if not candidates:
            continue
        end = candidates[int(run.rng.integers(len(candidates)))]
        move = RouteMove('inversion', 1, end)
        candidate = move.apply(rotated)
        if candidate in seen:
            continue
        seen.add(candidate)
        # Full verification for every repair proposal keeps the adapter simple.
        value = run.evaluate(candidate, evaluate_cost)
        if value is None:
            return None, None
        run.count('repair_gap_proposals')
        if value < best_cost:
            best, best_cost = candidate, value
            run.count('repair_improvements')
        if value == 0:
            return best, best_cost
        if value <= current_cost:
            current, current_cost = candidate, value
    return best, best_cost
