"""Run the evaluated v4 preset and export an array of original vertex labels."""

import argparse
import json
import math
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--instance', default='graph2', help='graph1 ... graph1001')
    parser.add_argument('--algorithm', choices=['ga', 'sa', 'as', 'abc', 'de', 'pso', 'all'], default='abc')
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--seconds', type=float, default=30, help='Budget per algorithm, including initialization')
    parser.add_argument('--catalog', type=Path, default=ROOT / 'docs/decisions/fhcp-catalog.json')
    parser.add_argument('--output-dir', type=Path, default=Path('results'))
    args = parser.parse_args()
    if not math.isfinite(args.seconds) or args.seconds <= 0 or int(args.seconds * 1_000_000_000) < 1:
        parser.error('--seconds must be positive and finite')
    if not 0 <= args.seed < 2**64:
        parser.error('--seed must be an unsigned 64-bit integer')
    catalog = args.catalog.resolve()
    output = args.output_dir.resolve()
    presets = json.loads((ROOT / 'experiments/configs/search-repair-v4-presets.json').read_text())['solvers']
    chosen = [p for p in presets if args.algorithm in ('all', p['algorithm'])]
    env = os.environ.copy()
    for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
        env[key] = '1'
    failed = False
    for preset in chosen:
        command = [sys.executable, '-m', 'src.cli', '--instance', args.instance,
                   '--algorithm', preset['algorithm'], '--seed', str(args.seed),
                   '--catalog', str(catalog), '--max-elapsed-ns', str(int(args.seconds * 1_000_000_000)),
                   '--output-dir', str(output)]
        for name, value in preset['parameters'].items():
            command.extend(['--' + name.replace('_', '-'), str(value)])
        completed = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True)
        if completed.stderr:
            print(completed.stderr, file=sys.stderr, end='')
        if not completed.stdout.strip():
            print(f'No RunRecord returned by {preset["algorithm"]}', file=sys.stderr)
            return completed.returncode or 1
        record = json.loads(completed.stdout)
        result = record['result']
        route = result['best_route']
        labels = None
        certified = False
        if route is not None:
            from src.graphs import load_fhcp_graph, route_to_external
            from src.evaluation import evaluate_cost, validate_cycle
            graph = load_fhcp_graph(args.instance, root=ROOT, manifest=catalog)
            assert evaluate_cost(graph, route) == result['best_cost'], 'Independent cost mismatch'
            certified = validate_cycle(graph, route).valid
            assert not result['success_within_budget'] or certified, 'Invalid claimed cycle'
            labels = list(route_to_external(graph, route))
        directory = output / record['run']['run_id']
        # The core CLI reserves a unique directory for every attempt.
        if not (directory / 'run.json').is_file():
            raise OSError('The complete RunRecord was not saved')
        with (directory / 'route.json').open('x', encoding='utf-8') as stream:
            json.dump(labels, stream)
            stream.write('\n')
        summary = {'algorithm': preset['algorithm'], 'instance': args.instance,
                   'seed': args.seed, 'status': result['status'], 'best_cost': result['best_cost'],
                   'certified_cycle': bool(result['success_within_budget'] and certified),
                   'route': labels, 'route_file': str(directory / 'route.json'),
                   'record_file': str(directory / 'run.json')}
        (directory / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(json.dumps(summary, ensure_ascii=False), flush=True)
        failed = failed or completed.returncode != 0
    return int(failed)


if __name__ == '__main__':
    raise SystemExit(main())
